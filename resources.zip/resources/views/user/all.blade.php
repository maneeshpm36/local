@extends('layouts.uapp')
@section('content')
<div class="row m-t-30">
    <div class="col-md-12">
        <!-- DATA TABLE-->
        <div class="table-responsive m-b-40">
            <table class="table table-borderless table-data3">
                <thead>
                    <tr>
                        <th>Sl NO</th>
                        <th>Roles</th>
                       
                    </tr>
                </thead>
                <?php $inc= 0;?>
                <tbody>


                @foreach ($apprls as $apr)
                    <tr>
                        <td> {{++$inc}} </td>
                        <td>{{$apr->rolename}}</td>
                     
                    </tr>
                @endforeach
                    
                </tbody>
            </table>
        </div>
        <!-- END DATA TABLE-->
    </div>
</div>
@endsection