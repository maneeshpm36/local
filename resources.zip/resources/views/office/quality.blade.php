<style>
.tree,
.tree ul,
.tree li {
  list-style: none;
  margin: 0;
  padding: 0;
  position: relative;
}

.tree {
  margin: 0 0 1em;
  text-align: center;
}

.tree,
.tree ul {
  display: table;
}

.tree ul {
  width: 100%;
}

.tree li {
  display: table-cell;
  padding: .5em 0;
  vertical-align: top;
}

.tree li:before {
  outline: solid 1px #666;
  content: "";
  left: 0;
  position: absolute;
  right: 0;
  top: 0;
}

.tree li:first-child:before {
  left: 50%;
}

.tree li:last-child:before {
  right: 50%;
}

.tree code,
.tree span {
  display: inline-block;
  margin: 0 .2em .5em;
  padding: 3.7em .5em;
  position: relative;
  height: 100px;
  width: 150px;
  border-radius: 50%;
  background-color: #fefefe;
}

.lineh {
  margin-top: -9px !important;
  margin-bottom: 0px !important;
  border: 0 !important;
  border-top: 2px solid !important;
  width: 159px;
}

.minus-space {
  margin-top: 10px !important;
}

.tree span i {
  font-size: 40px
}

.tree span.level1 {
  background-color: #1e1e1e;
  color: yellow;
  padding: 2em .5em !important;
}

.tree span.level2 {
  background-color: #ffcc01;
  padding: 2em .5em !important;
}

.tree span.linev {
  background-color: #666 !important;
  width: 2px !important;
  border-radius: 0% !important;
  padding: 0px !important;
  margin: 0px !important;
}

.tree ul:before,
.tree code:before,
.tree span:before {
  outline: solid 1px #666;
  content: "";
  height: .5em;
  left: 50%;
  position: absolute;
}

.tree ul:before {
  top: -.5em;
}

.tree code:before,
.tree span:before {
  top: -.55em;
}

.tree>li {
  margin-top: 0;
}

.tree>li:before,
.tree>li:after,
.tree>li>code:before,
.tree>li>span:before {
  outline: none;
}
</style>

<section class="content">

<div class="container-fluid">
  <ul class="tree">

  


    <li><span class="level1"><i class="mdi mdi-bank"></i><br>
    @foreach($places as $offices)
    @if($offices->ClassCode =='CIR')
    <b>{{ $offices->Office_Code }}<br>{{ $offices->Office_Name }}</b>
    @endif
    @endforeach
    </span>
      <ul>
       
          <ul>
          @foreach($places as $offices)
         @if($offices->ClassCode =='DIV')

            <li> <span class="level2">{{ $offices->Office_Code }}<br>{{ $offices->Office_Name }}</span>
            </li>
         
            @endif
            @endforeach
            <li> <span class="linev"></span>
              <ul>


              @foreach($places as $offices)
         @if($offices->ClassCode =='SUB')


         
                  <li> <span class="level1"><i class="mdi mdi-bank"></i><br><b>{{ $offices->Office_Code }}</b><br>{{ $offices->Office_Name }}</span>
                  </li>

            @endif
            @endforeach

              


                <li> <span class="linev"></span>
                  <ul>


                @foreach($places as $offices)
                @if($offices->ClassCode =='QLAB')
     
                  <li> <span class="level2"><i class="mdi mdi-bank"></i><br><b>{{ $offices->Office_Code }}</b><br>{{ $offices->Office_Name }}</span>
                  </li>
                @endif
                @endforeach

                   
                   

                  </ul>
                </li>
               
              </ul>
            </li>
            
          </ul>
        
      </ul>
    </li>








  </ul>
</div>

</section>