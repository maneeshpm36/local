
<!DOCTYPE html>
<html>
<head>
<title>Kerala Water Authority SSO</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- Custom Theme files -->
<link href="{{asset('login/style.css')}}" rel="stylesheet" type="text/css" media="all" />
<!-- //Custom Theme files -->
<!-- web font -->
<link href="//fonts.googleapis.com/css?family=Roboto:300,300i,400,400i,700,700i" rel="stylesheet">
<!-- //web font -->
<link rel="icon" href="{{asset('img/favicon.ico')}}" type="image/x-icon"/>

<style>


.button {
  background-color: #4CAF50; /* Green */
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.button2 {background-color: #008CBA;} /* Blue */
.button3 {background-color: #f44336;} /* Red */ 
 /* .button2:hover , .button3:hover {
  background-color: #0a7697;
} */


.logconsumer {
    display: none;
}
	




	</style>



<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>


<script>
	$(document).ready(function(){

	  $(".button2").click(function(){
		
        $(".logconsumer").show();
        $(".logemp").hide();

	  });

	  $(".button3").click(function(){
		
        $(".logconsumer").hide();
		$(".logemp").show();

	  });
   
	});
	</script> -->






</head>
<body>
	<!-- main -->
	<div class="main-w3layouts wrapper">
		<h1>Kerala Water Authority SSO</h1>
		<div class="main-agileinfo">

		    <div class="agileits-top">
			     <a class="button button2" href="{{ route('consumer') }}"> Consumer</a>
				<a class="button button3" href="{{url('/')}}"> Employee</a>
		   </div>




				@if (session('status'))
									<div class="alert alert-success">
                        {{ session('status') }}
                    </div>
                @endif


			<div class="agileits-top logemp">
				<p>Employee Login</p>
				<form action="{{url('Slogin')}}" method="post">
					<input class="text" type="text" name="Username" placeholder="PEN/Employee NUMBER" required="">

                    <br/>

					<input class="text" type="password" name="password" placeholder="Password" required="">
					<input name="_token" type="hidden" value="{{ csrf_token() }}"/>
					
                     
					<input type="submit" value="Login">

				
				</form>
				<p>Don't have an Account? <a href="{{ route('Sregister') }}"> Register Now!</a></p>
			</div>

            <div class="agileits-top logconsumer">
				<p>Consumer Login</p>
				<form action="{{url('Clogin')}}" method="post">
					<input class="text" type="text" name="Username" placeholder="Mobile Number" required="">
                    <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                  
					<br/>
					<input class="text" type="password" name="password" placeholder="Password" required="">

					
                     
					<input type="submit" value="Login">
					

				</form>
				<p>Don't have an Account? <a href="{{ route('Cregister') }}"> Register Now!</a></p>
			</div> 





		</div>
		<!-- copyright -->
		<div class="colorlibcopy-agile">
			<p>© 2021  All rights reserved | Design by <a href="https://kwa.kerala.gov.in/" target="_blank">Kerala Water Authority</a></p>
		</div>
		<!-- //copyright -->
		<ul class="colorlib-bubbles">
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
			<li></li>
		</ul>
	</div>
	<!-- //main -->
</body>
</html>
