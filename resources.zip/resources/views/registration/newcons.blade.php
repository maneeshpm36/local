




<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Kerala Water Authority Staff Registration">
    <meta name="author" content="Kerala Water Authority Staff Registration">
    <meta name="keywords" content="Kerala Water Authority Staff Registration">

    <!-- Title Page-->
    <title>Kerala Water Authority Staff Registration</title>

    <!-- Icons font CSS-->
    <link href="{{asset('regist/vendor/mdi-font/css/material-design-iconic-font.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('regist/vendor/font-awesome-4.7/css/font-awesome.min.css')}}" rel="stylesheet" media="all">
    <!-- Font special for pages-->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">

    <!-- Vendor CSS-->
    <link href="{{asset('regist/vendor/select2/select2.min.css')}}" rel="stylesheet" media="all">
    <link href="{{asset('regist/vendor/datepicker/daterangepicker.css')}}" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="{{asset('regist/css/main.css')}}" rel="stylesheet" media="all">
    <link rel="icon" href="{{asset('img/favicon.ico')}}" type="image/x-icon"/>

    <style>
    #errNm1 {
        color: red;
    }
    </style>



</head>

<body>
    <div class="page-wrapper bg-yellow p-t-100 p-b-100 font-robo">
        <div class="wrapper wrapper--w680">
            <div class="card card-1">
                <div class="card-heading"></div>
                <div class="card-body">
                    <h2 class="title">Consumer Registration </h2>
                    <form method="POST" action="{{url('Cregister')}}">
                        <div class="input-group">
                            <input class="input--style-1" type="text" placeholder="NAME" name="name">
                        </div>
                           @error('name')
                            <span id="errNm1">{{ $message }}</span>
                           @enderror
                        <div class="input-group">
                            <input class="input--style-1" type="email" placeholder="Email" name="email">
                        </div>
                        @error('email')
                        <span id="errNm1">{{ $message }}</span>
                       @enderror
                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="Phone" name="phone">
                        </div>
                        @error('phone')
                        <span id="errNm1">{{ $message }}</span>
                       @enderror
                        <div class="input-group">
                            <input class="input--style-1" type="number" placeholder="Adhaar" name="aadhar">
                            <input name="_token" type="hidden" value="{{ csrf_token() }}"/>
                        </div>
                        

                        
                        <div class="input-group">
                            <input class="input--style-1" type="password" placeholder="Password" name="password">
                           
                        </div>

                        @error('password')
                        <span id="errNm1">{{ $message }}</span>
                       @enderror

                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-1" type="text" placeholder="Consumer Id" name="consumerid">
                                </div>
                            </div>
                        </div>
                        @error('consumerid')
                        <span id="errNm1">{{ $message }}</span>
                       @enderror

                        <div class="row row-space">
                            <div class="col-2">
                                <div class="input-group">
                                    <input class="input--style-1" type="text" placeholder="Consumer number" name="consumerno">
                                </div>
                            </div>
                        </div>

                        @error('consumerno')
                        <span id="errNm1">{{ $message }}</span>
                       @enderror


                        <div class="p-t-20">
                           
                            <input class="btn btn--radius btn--green" type="submit" value="Submit" >
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="{{asset('regist/vendor/jquery/jquery.min.js')}}"></script>
    <!-- Vendor JS-->
    <script src="{{asset('regist/vendor/select2/select2.min.js')}}"></script>
    <script src="{{asset('regist/vendor/datepicker/moment.min.js')}}"></script>
    <script src="{{asset('regist/vendor/datepicker/daterangepicker.js')}}"></script>

    <!-- Main JS-->
    <script src="{{asset('regist/js/global.js')}}"></script>

</body>
</html>
<!-- end document-->
