@extends('layouts.users')

@section('content')
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<script src="{{asset('dash/plugins/canvas/js/jquery-1.11.1.min.js')}}"></script> 
<script src="{{asset('dash/plugins/canvas/js/jquery.canvasjs.min.js')}}"></script>
<script src="{{asset('dash/plugins/ajax/jquery.validate.min.js')}}"></script>
<link rel="stylesheet" href="{{asset('dash/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('dash/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('dash/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')}}">


<style>
  .modal-header
{  
  background-color: #96d7de !important;
}
* {box-sizing: border-box}
body {
  font-size: 15px;
  font-family: "Lato", sans-serif;}

/* Style the tab */
.tab {
  float: left;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
  width: 16%;
  height: 564px;
}

/* Style the buttons inside the tab */
.tab button {
  display: block;
  background-color: inherit;
  color: black;
  padding: 7px 16px;
  width: 100%;
  border: none;
  outline: none;
  text-align: left;
  cursor: pointer;
  transition: 0.3s;
  font-size: 17px;
  border: 1px solid #ccc;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

/* Create an active/current "tab button" class */
.tab button.active {
  background-color: #96d7de;
}

/* Style the tab content */
.tabcontent {
  float: left;
  /* padding: 0px 12px; */
  /* border: 1px solid #ccc; */
  border: 5px solid #96d7de;
  width: 84%;
  border-left: none;
  /* height: 300px; */
}
.pic_head thead,.table_cls thead
{
  color: #b91e82;
}
.head_cls
{
text-align:center;
font-weight: bold;
color: #b91e82;
height: 31px;
padding: 5px;
/* background-color: #c9f7f9; */

}
.welcome_cls
{
text-align:left;
font-weight: bold;
color: #a234e6d6;
height: px;
padding-left: 16px;
padding-top: 7px;

}

.mandatory_cls, label.error
{
  color: red !important;
  margin-left: 4px;
  font-size: 12px !important;
}
input[type=text], input[type=number] {
    width: 96% !important;
    padding: 5px 6px;
    border: 1px solid #ccc;
    border-radius: 4px;
}
.btn_color
{
  background-color: #008CBA;
  color: white !important;
  border-radius: 4px;
}
.remarks_cls
{
  width: 95%;
  height: 55px;
  padding: 5px 6px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.alert,.meter_alert
{
  color: green;
  font-weight: bold;
}
.canvasjs-chart-credit {
    display: none;
  }
  input[type=date]{    
    padding: 5px 6px;
    border: 1px solid #ccc;
    border-radius: 4px;
}

</style>

</head>
<body>
<meta name="csrf-token" content="{{ csrf_token() }}">

<h6 class="welcome_cls">WELCOME, {{ $consumers[0]->consumer_name }}</h6>
<!-- <p>Click on the buttons inside the tabbed menu:</p> -->

<div class="tab">
  <button class="tablinks" onclick="openTab(event, 'Home')" id="defaultOpen">Home</button>
  <button class="tablinks" onclick="openTab(event, 'View_profile')" >View Profile</button>
  <button class="tablinks" onclick="openTab(event, 'payment_details')" >Payment Details</button>  
  <button class="tablinks" onclick="openTab(event, 'Update_profile')">Update Profile</button>
  <button class="tablinks" onclick="openTab(event, 'update_meter_reading')">Add Meter Reading</button>
</div>

<div id="Home" class="tabcontent">
  <h5 class="head_cls">Water Consumption Details</h5>
                   
  <div id="chartContainer" style="height: 300px;max-width: 100% !important;"></div>
  </br>
  <div style="max-height: 400px;  overflow: auto;">
  <table class="table table-bordered table-striped table-hover pic_head" id="pic_table" style='border-collapse: collapse;'>

    <thead>
            <tr>                                
                <th><b>Sl No</b></th>    
                <th><b>Consumption(Kilo Liter)</b></th>
                <th><b>Charge(Rs)</b></th>
                <th><b>Consumption From</b></th>
            </tr>
        </thead>                        
        <tbody>
        @if($pic_details)
            @foreach($pic_details as $index => $pic)
          <tr>       
              <td> {{ $index+1 }}</td>
              <td> {{ $pic->pic_kl }}</td> 
              <td> {{ $pic->pic_amt }}</td>
              <td> {{ date('d-M-Y', strtotime($pic->pic_from)) }}</td>
              
          </tr>  
            @endforeach
          @endif  
        </tbody>
</table>
  </div>
                      
 </div>
</div>


<div id="View_profile" class="tabcontent">
  <h5 class="head_cls">View Profile Details</h5>
  <table class="table table-bordered table-hover">
                          <thead>                            
                          </thead>
                          <tbody>
                            <tr>
                              <td><b>Consumer Id</b></td>
                              <td>{{ $consumers[0]->consumer_id }}</td>
                              <td><b>Consumer Number</b></td>
                              <td>{{ trim($consumers[0]->area_code) }}/{{ $consumers[0]->consumer_no }}/{{ $consumers[0]->consumer_category }}</td>
                             </tr>
                             <tr>
                              <td><b>Consumer Type</b></td>
                              @if($consumers[0]->consumer_category == 'D')
                                <td colspan="3">DOMESTIC</td>
                              @elseif($consumers[0]->consumer_category == 'N')
                                <td colspan="3">NON DOMESTIC</td>
                                @elseif($consumers[0]->consumer_category == 'S')
                                <td colspan="3">SPECIAL</td>
                                @elseif($consumers[0]->consumer_category == 'I')
                                <td colspan="3">INDUSTRIAL</td>
                                @else
                                <td></td>
                              @endif  
                              
                              
                            <tr>
                              <td><b>Name</b></td>
                              <td>{{ $consumers[0]->consumer_name }}</td>
                              <td><b>Registered Mobile No.</b></td>
                              <td id="con_mobile">{{ $user_mob_details[0]->user_mobile }}</td>                              
                               </tr>

                            <tr>
                            <td><b>Address</b></td>
                              <td >{{ $consumers[0]->consumer_address1 }}
                              </br>{{ $consumers[0]->consumer_address2 }}<br>{{ $consumers[0]->consumer_address3 }}</br>
                              {{ $consumers[0]->consumer_address4 }}</td>
                              <td><b>Date of Connection</b></td>
                              <td>{{ date('d-M-Y', strtotime($consumers[0]->date_connect)) }}</td>
                            </tr>
                            <tr>
                            <td><b>Flats</b></td>
                            @if($consumers[0]->flat == 'N') 
                                <td>NO</td>    
                                @elseif($consumers[0]->flat == 'Y')
                              <td>YES</td>   
                               @else
                               <td></td>        
                                @endif                             
                            <td><b>No. Of Flats</b></td>
                            @if($consumers[0]->no_of_flats != '')
                            <td>{{ $consumers[0]->no_of_flats }}</td>
                            @else
                            <td>--</td>        
                                @endif  

                            </tr>

                            <tr>
                            <td><b>Meter Number</b></td>
                              <td>{{ $consumers[0]->meter_no }}</td>
                              <td><b>Meter Working</b></td>
                              @if($consumers[0]->meter_working == 'N') 
                                <td>NO</td>    
                                @elseif($consumers[0]->meter_working == 'Y')
                              <td>YES</td>   
                               @else
                               <td></td>        
                                @endif 
                              
                                                        
                            </tr>

                            <tr>
                            <td><b>Connection Status</b></td>
                              @if($consumers[0]->disconnect == 'N') 
                                <td>CONNECTED</td>    
                                @elseif($consumers[0]->disconnect == 'Y')
                              <td>DISCONNECTED</td>   
                              @else
                               <td>NA</td>        
                                @endif     
                              <td><b>Last Reading</b></td>
                              <td>{{ $consumers[0]->last_reading }}</td>
                            
                            </tr>
                            <tr>
                            <td><b>Last Reading Status</b></td>
                              @if($consumers[0]->last_reading_status == 'W') 
                                <td>WORKING</td>
                              @elseif($consumers[0]->last_reading_status == 'D') 
                                <td>DISCONNECTED</td> 
                              @elseif($consumers[0]->last_reading_status == 'T') 
                              <td>NO CONSUMPTION</td>  
                              @elseif($consumers[0]->last_reading_status == 'E') 
                              <td>LESS THAN PREVIOUS READING</td> 
                              @elseif($consumers[0]->last_reading_status == 'L') 
                              <td>GATE/DOOR/CHAMBER LOCKED</td> 
                              @elseif($consumers[0]->last_reading_status == 'F') 
                              <td>METER NOT WORKING</td> 
                              @elseif($consumers[0]->last_reading_status == 'R') 
                              <td>NOT CLEAR</td>           
                              @elseif($consumers[0]->last_reading_status == 'S') 
                              <td>NOT SEEN</td> 
                              @elseif($consumers[0]->last_reading_status == 'C') 
                              <td>NOT ACCESS</td> 
                              @elseif($consumers[0]->last_reading_status == 'M') 
                              <td>SAME READING</td>                              
                               @else
                               <td></td>        
                                @endif 
                              <td><b>Last Reading Date</b></td>
                              <td colspan="3">{{ date('d-M-Y', strtotime($consumers[0]->last_reading_date)) }}</td>                             
                            </tr>
                            <tr>
                           <td><b>Office Name</b></td>
                           <td colspan="3">  <a href="" data-toggle="modal" id="meterNo" data-target="#smallModal">
                           {{ $office_name[0]->officename }}
                              </a></td> 
                           </tr> 
                            <tr>    
                              <td><b>Scheme Name</b></td>
                              @if($project_name) 
                                <td colspan="3">{{ $project_name[0]->project_name }}</td>    
                                @else
                              <td colspan="3"></td>        
                                @endif 
                            </tr>                                            
                          </tbody>
                        </table>
</div>

<div id="payment_details" class="tabcontent">
 <h5 class="head_cls">Last Payment Details</h5>
  <table id="example"  class="table table-bordered table-striped table_cls">                       
    <thead>
        <tr>                                
            <th><b>Bill Number</b></th>    
            <th><b>Paid Date</b></th>
            <th><b>Paid Amount(Rs)</b></th>
            <th><b>Receipt Number</b></th>
        </tr>
    </thead>                        
    <tbody>
        @foreach($bill_details as $bill)
      <tr>       
          <td> {{ $bill->bill_id }}</td> 
          <td> {{ date('d-M-Y', strtotime($bill->paid_date)) }}</td>
          <td> {{ $bill->total_colletd }}</td>
          <td> {{ $bill->receipt_no }}</td> 
      </tr>  
        @endforeach
    </tbody>
    
  </table>
  <hr>
  <form method="post" name="bill_form" id="bill_form" style="text-align:center">
                          @csrf
    <h5 class="head_cls"> Detailed Payment Details</h5>   
    <hr>                   
    <label>From:<span class="mandatory_cls">*</span></label>
      <input type="date" id="from_date" name="from_date">

      <label>To:<span class="mandatory_cls">*</span></label>
      <input type="date" id="to_date" name="to_date">
      <input type="submit" class="btn_color btn">
      <input type="hidden" id="area_code" name="area_code" value="<?php echo $consumers[0]->area_code ?>">
  </form>


  <table id="example1"  class="table table-bordered table-striped table_cls payment_cls">                       
    <thead>
        <tr>                                
            <th><b>Bill Number</b></th>    
            <th><b>Paid Date</b></th>
            <th><b>Paid Amount(Rs)</b></th>
            <th><b>Receipt Number</b></th>
        </tr>
    </thead>                        
    <!-- <tbody>
       <div id="pay_details"></div>
    </tbody> -->
    
  </table>
  
</br>

</div>

<div id="Update_profile" class="tabcontent">
  <h5 class="head_cls">Update Profile Details</h5>
  <form method="post" name="consumer_update_form" id="consumer_update_form">
                          @csrf
                          <table class="table table-bordered table-hover" id="consumer_update">
                                                   
                          <tbody>
                            <tr>
                              <td><b>Registered Mobile No.<span class="mandatory_cls">*</span></b></td>
                              <td><input type="number"  pattern="\d{3}[\-]\d{3}[\-]\d{4}" id="mobile_no" value="{{ $user_mob_details[0]->user_mobile }}" maxlength="10" name="mobile_no" required="required">
                                                         
                          </td>
                          <td><b>Date Of Birth</b></td>
                              <td> <input type="date" name="dob" id="dob">
                                                                                       
                          </td>
                          </tr>
                          <tr>
                          <td><b>Are you married?</b></td>
                              <td><input type="checkbox" id="married" onchange="checkboxChecked()" value="{{ $consumers[0]->married }}">&nbsp;Yes
                            </td>    
                              
                               <td class="checked_married"><b>Weeding Anniversary Date</b><span class="mandatory_cls">*</span></td>
                               <td class="checked_married"> <input type="date" name="anniversary_date" id="anniversary_date" value="{{ $consumers[0]->anniversary_date }}"></td>

                                </tr>
                              

                            <tr>
                            <td><b>Total No. Of Persons</b></td>
                              <td><input type="number" id="no_of_persons" value="{{ $consumers[0]->no_of_persons }}"  maxlength="2" name="no_of_persons"></td>                             
			                                                   
                          </td>
                          <td><b>No: Of Persons below 14</b></td>
                              <td><input type="number" id="no_below" class="persons1" value="{{ $consumers[0]->no_of_persons_below }}"  maxlength="2" name="no_below">
                                
                               </tr>                          

                            <tr>
                            <td><b>No. Of Persons between 14-60</b></td>
                              <td><input type="number" id="no_between" class="persons1" value="{{ $consumers[0]->no_of_persons_between }}"  maxlength="2" name="no_between"></td>                             
			                     
                              <td><b>No: Of Persons Above 60</b></td>
                              <td><input type="number" id="no_above" class="persons1" value="{{ $consumers[0]->no_of_persons_above }}"  maxlength="2" name="no_above">
                                                       
                          
                            <tr>                        

                             
                            <tr>
                            <td><b>GIS Longitude</b></td>
                              <td><input type="text" name="gis_long" id="gis_long" value="{{ $consumers[0]->gis_long }}"></td>
                              <td><b>GIS Latitude</b></td>
                              <td><input type="text" name="gis_lati" id="gis_lati" value="{{ $consumers[0]->gis_latid }}"></td>
                             
                            </tr>
                            <tr>
                              
                            <td><b>Remarks</b></td>
                           <td><textarea id="remarks" class="remarks_cls" name="remarks">{{ $consumers[0]->remarks }}</textarea>
                           </td>                             
                         
                         </tr>
                            <tr>
                            <td colspan="4" class="text_align">
                            <button type="submit" id="update_info" class="btn_color btn">
                                  Submit
                                </button>
                                <input type="reset" value="Reset" class="btn_color btn">
                                 
                                <span class="alert"></span>  
                             </tr>
                          </table>
                          <input type="hidden" id="consumer_id" name="consumer_id" value="<?php echo $consumers[0]->consumer_id ?>">
                          <input id="total_persons" type="hidden" name="total_persons" value="">
                          </form>
</div>

<div id="update_meter_reading" class="tabcontent">
  <h5 class="head_cls">Add Meter Reading</h5>
  <form method="post" name="meter_reading_form" id="meter_reading_form" action="javascript:void(0)" enctype="multipart/form-data">
                          @csrf
  <table class="table table-bordered table-hover">
 <tr>
 <td><b>Current Meter Reading<span class="mandatory_cls">*</span></b></td>
  <td><input type="number" id="current_meter_reading" name="current_meter_reading"></td>                             
  <td><b>Upload Meter Image</b></td>  
  <td><input type="file" name="file" id="file"></td>    
 </tr>
 <tr>
    <td colspan="4" class="text_align">
<button type="submit" id="meter_info" class="btn_color btn">Submit</button>
<span class="meter_alert"></span>  
    </td>
   </tr>
  </table>
  </form>

  <h5 class="head_cls">Meter Details</h5>
  <div style="max-height: 400px;  overflow: auto;">
  <table id="example"  class="table table-bordered table-striped table_cls meter_cls">                       
    <thead>
        <tr>                                
            <th><b>Serial No.</b></th>    
            <th><b>Meter Reading</b></th>
            <th><b>Meter Image</b></th>
           
        </tr>
    </thead>                        
    <tbody>
    @if($meter_details)
        @foreach($meter_details as $index =>$meter)
      <tr>       
          <td>{{ $index+ 1 }}</td> 
          <td>{{ $meter->current_meter_reading }}</td>
         @if($meter->reading_image)
        
           <td><a href="{{ URL::to('/') }}/meter_image/{{ $meter->reading_image }}">View</a></td>
         @else   
         <td>Image Not Uploaded</td>
         @endif 
          <td></td>          
      </tr>  
        @endforeach
    @endif    
    </tbody>    
  </table>
  </div>
</div>

<div class="modal fade" id="smallModal" tabindex="-1" role="dialog" aria-labelledby="smallModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header"><b>OFFICE DETAILS</b>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    
                </div>
                <div class="modal-body" id="smallBody">
                    <div>
                    <table class="table table-bordered table-striped table-hover" id="meter_table" style='border-collapse: collapse;'>
          <thead>
            <tr>
              <td><b>Circle Office Name</b></td>          
              @if($parentcircle_name) 
              <td>{{ $parentcircle_name[0]->officename }}</td>    
              @else
              <td></td>        
              @endif 
            </tr>
            <tr>
              <td><b>Division Office Name</b></td>
              @if($parentdivision_name) 
              <td>{{ $parentdivision_name[0]->officename }}</td>    
              @else
              <td></td>        
              @endif 
            </tr>
            <tr>
              <td><b>SubDivision Office Name</b></td>
              @if($parentsubdiv_name) 
              <td>{{ $parentsubdiv_name[0]->officename }}</td>    
              @else
              <td></td>        
              @endif          
            </tr>
            
          </thead>
        <tbody></tbody>
     </table>
                        <!-- the result to be displayed apply here -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="{{asset('dash/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-responsive/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')}}"></script>
<script src="{{asset('dash/plugins/jszip/jszip.min.js')}}"></script>
<script src="{{asset('dash/plugins/pdfmake/pdfmake.min.js')}}"></script>
<script src="{{asset('dash/plugins/pdfmake/vfs_fonts.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/buttons.html5.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/buttons.print.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/buttons.colVis.min.js')}}"></script>




<script>
  $(document).ready(function() {    

    //date of birth
    var dtToday = new Date();    
    var month = dtToday.getMonth() + 1;
    var day = dtToday.getDate();
    var year = dtToday.getFullYear();
    if(month < 10)
        month = '0' + month.toString();       
    if(day < 10)
        day = '0' + day.toString();
        
    var maxDate = year + '-' + month + '-' + day;  
    $('#dob').attr('max', maxDate); 
    
    $('#anniversary_date').attr('max', maxDate); 
     
    $(".checked_married").hide();
    $(".payment_cls").hide();    
    $(".alert").hide();

     if($('#married').val() == 'Y')
     {
      $('#married').prop('checked', true);
      $(".checked_married").show();
     }

   
      $('.persons1').change(function() {
  
    var sum = 0;
    $(".persons1").each(function(){
        sum += +parseInt($(this).val());
    });
    $('#total_persons').val(sum);
  });

});

function checkboxChecked()
    {       
        if($('#married').is(":checked"))   
        { 
            $('#married').val('Y');  
            $(".checked_married").show();
        }
        else
        { 
           $('#married').val('N');
           $('#anniversary_date').val('');
           $(".checked_married").hide();
        }
    }

function openTab(evt, cityName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();

window.onload = function () {

var options = {
	animationEnabled: true,	
	axisY: {
		title: "Kilo Liter",
    titleFontColor: "red",    
    labelFontColor: "#3c00bb",
	},
	axisX: {
		title: "Month",
    titleFontColor: "red",
    labelFontColor: "#3c00bb",

	},
	data: [{
		type: "spline",
		yValueFormatString: "#,##0.0#",
    
		dataPoints: [
			<?php
      if($pic_graph_details)
      {
      foreach($pic_graph_details as $pic_graph) 

      { 
        ?>
			 { label: <?php echo "'".date('d-M-Y', strtotime($pic_graph->pic_from))."'" ?>, y: <?php echo $pic_graph->pic_kl ?> },
      <?php } 
      }  ?>
			
		]
	}]
};
$("#chartContainer").CanvasJSChart(options);
}

if ($("#consumer_update_form").length > 0) {
    $("#consumer_update_form").validate({      
    rules: {
      mobile_no: {
        required: true,
        maxlength: 10,
        minlength: 10
      },
      anniversary_date:{
        required:"#married:checked",
        }, 
        no_of_persons:
        {
          equalTo: "#total_persons",          
        }        
    },
    messages: {
      mobile_no: {
         required: "Please Enter Mobile No.",
         maxlength: "Maximum length should be 10",
         minlength: "Minimum length should be 10"
      },
      anniversary_date: {
        required: 'Please select anniversary date'
        },
        no_of_persons:
        {
          maxlength: "Maximum limit is 99",
          equalTo: "Total no of persons = No: Of Persons below 14 + No. Of Persons between 14-60 + No: Of Persons Above 60"
        },
        no_below,no_between,no_above:
        {
          maxlength: "Maximum limit is 99",
        }     
    },
    submitHandler: function(form) {
     $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });     
       $.ajax({
                  url: "Consumerupdate",
                  method: 'post',
                  data: {
                    consumer_id: $('#consumer_id').val(),
                    mobile_no: $('#mobile_no').val(),
                    no_of_persons: $('#no_of_persons').val(),
                    no_of_persons_below:$("#no_below").val(),
                    no_of_persons_between:$("#no_between").val(),
                    no_of_persons_above:$("#no_above").val(),
                    married: $('#married').val(),   
                    anniversary_date: $('#anniversary_date').val(),
                    remarks: $('#remarks').val(),
                    gis_long: $('#gis_long').val(),    
                    gis_lati: $('#gis_lati').val(),                   
                  },
                  success: function(result){  
                    $(".alert").show();
                     $('.alert').html(result.success);                     
                     $("#con_mobile").html($('#mobile_no').val());
                  }
           });
    }
  })
}


if ($("#bill_form").length > 0) {
    $("#bill_form").validate({
      
    rules: {
      from_date: 
      {
        required: true
      },
      to_date: 
      {
        required:true 
      }
    },
    messages: {
      from_date: {
         required: "Please Select From Date"        
      },
      to_date: {
         required: "Please Select To Date"        
      }
    },
    submitHandler: function(form) {
     $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
     
       $.ajax({
                  url: "GetBillDetails",
                  method: 'post',
                  data: {
                    consumer_id: $('#consumer_id').val(),
                    from_date: $('#from_date').val(),
                    to_date: $('#to_date').val(),
                                     
                  },
                  success: function(data){  
                    $(".payment_cls").show();
                   $.each( JSON.parse(data), function( key, value ) {  
                    // var newDate = strtotime(value.paid_date);
                    // console.log(newDate)
                    $(".payment_cls").append('<tr><td>'+value.bill_id+'</td><td>'+value.paid_date+'</td><td>'+value.total_colletd+'</td><td>'+value.receipt_no+'</td></tr>');
                        
                    

                    });  

                    $("#example1").DataTable({
                      paging: false,
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["pdf", "print"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');     
      
      $('#example1_wrapper').prepend();   
                     
                  }
           });
    }
  })
}

//update meter reading details
  
   

  if ($("#meter_reading_form").length > 0) {
  
    $("#meter_reading_form").validate({
      
    rules: {
      current_meter_reading: 
      {
        required: true
      },
     },
    messages: {
      current_meter_reading: {
         required: "Please enter current meter reading"        
      },      
    },
    submitHandler: function(form) {
      var formData = new FormData(form);    
    formData.append('current_meter_reading', $('#current_meter_reading').val());
    formData.append('consumer_id', $('#consumer_id').val());
    
     $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
     
      
       $.ajax({
      url: "UpdateMeterReading",
      method: 'post',
      data: formData,
      cache:false,
      contentType: false,
      processData: false,
      success: (data) => {
       form.reset();
       var i = 1;
       $(".meter_cls tbody").empty();
       $.each( JSON.parse(data), function( key, value ) {  

        var view_image;  
        if(value.reading_image)
        {
          view_image = '<a href="">View</a>';
        }else
        {
          view_image = 'Image Not Uploaded';
        }       

        $(".meter_cls tbody").append('<tr><td>'+i+'</td><td>'+value.current_meter_reading+'</td><td>'+view_image+'</td></tr>');
                    i++;    

                    });  
       $('.meter_alert').html('Added Meter Reading successfully!');     
       setTimeout(function() {
        $('.meter_alert').empty();
      }, 2000); 
       
      },
        error: function(data){      
      }
           });
    }
  })
}













</script>
   
</body>
</html> 
@endsection