@extends('layouts.users')

@section('content')

<!-- DataTables -->
<link rel="stylesheet" href="{{asset('dash/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('dash/plugins/datatables-responsive/css/responsive.bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('dash/plugins/datatables-buttons/css/buttons.bootstrap4.min.css')}}">

<style>
.bck_cls,.modal-header
{  
  background-color: #96d7de !important;
}

.bill_bck_cls
{  
  background-color: #ddfcff !important;
}
.btn-secondary
{
  background-color: #1f7680 !important;
}
#example1_wrapper
{  
  border: 1px solid #dadada;   
}
.pay_cls
{
  height: 52px !important;
  padding: 15px;
  background-color: #96d7de !important;
  text-align:center;
}
#example1, .text_align
{
  text-align:center;
}
.pic_modal
{
  max-height: 500px;
  overflow: auto;
}
.btn_color
{
  background-color: #008CBA;
  color: white !important;
  border-radius: 4px;
}
input[type=text], input[type=number] {
    width: 96% !important;
    padding: 5px 6px;
    border: 1px solid #ccc;
    border-radius: 4px;
}
.alert
{
  color: green;
  font-weight: bold;
}
.mandatory_cls, .error
{
  color: red !important;
}
.remarks_cls
{
  width: 95%;
  height: 55px;
  padding: 5px 6px;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.main-footer
{
  margin-left: 0px !important;
}
</style>

 <!-- Content Wrapper. Contains page content -->

 <meta name="csrf-token" content="{{ csrf_token() }}">
 <div class="content-wrapper">
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container">
      <div class="row mb-2">
        <div class="col-sm-6">

          <h1 class="m-0">   
            
            {{-- Top Navigation  {{ session()->get('cid') }}<small>Example .0 </small> --}}
          
          
          </h1>
        </div><!-- /.col -->
        {{-- <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item"><a href="#">Layout</a></li>
            <li class="breadcrumb-item active">Top Navigation</li>
          </ol>
        </div> --}}
        
        <!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content-header -->

  <!-- Main content -->
  <div class="content">
    <div class="container">

                 <div class="row bck_cls">
                  <div class="col-12">
                    <div class="card">
                      <div class="card-header bck_cls">                       
                        <h6 style="text-align:center;"><b>PERSONAL INFORMATION</b></h6>
                      </div>
                      <!-- ./card-header -->
                      <div class="card-body">
                        <table class="table table-bordered table-hover">
                          <thead>                            
                          </thead>
                          <tbody>
                            <tr>
                              <td><b>Consumer Id</b></td>
                              <td>{{ $consumers[0]->consumer_id }}</td>
                              <td><b>Consumer Number</b></td>
                              <td>{{ trim($consumers[0]->area_code) }}/{{ $consumers[0]->consumer_no }}/{{ $consumers[0]->consumer_category }}</td>
                             </tr>
                            <tr>
                              <td><b>Name</b></td>
                              <td>{{ $consumers[0]->consumer_name }}</td>
                              <td><b>Mobile No.</b></td>
                              <td id="con_mobile">{{ $user_mob_details[0]->user_mobile }}</td>                              
                               </tr>

                            <tr>
                            <td><b>Address</b></td>
                              <td >{{ $consumers[0]->consumer_name }}</br>{{ $consumers[0]->consumer_address1 }}
                              </br>{{ $consumers[0]->consumer_address2 }}<br>{{ $consumers[0]->consumer_address3 }}</br>
                              {{ $consumers[0]->consumer_address4 }}</td>
                              <td><b>Date of Connection</b></td>
                              <td>{{ date('d-M-Y', strtotime($consumers[0]->date_connect)) }}</td>
                            </tr>
                            <tr>
                            <td><b>Flats</b></td>
                            @if($consumers[0]->flat == 'N') 
                                <td>NO</td>    
                                @elseif($consumers[0]->flat == 'Y')
                              <td>YES</td>   
                               @else
                               <td></td>        
                                @endif                             
                            <td><b>No. Of Flats</b></td>
                            <td>{{ $consumers[0]->no_of_flats }}</td>
                            </tr>

                            <tr>
                            <td><b>Meter Number</b></td>
                              <td>{{ $consumers[0]->meter_no }}</td>
                              <td><b>Meter Working</b></td>
                              @if($consumers[0]->meter_working == 'N') 
                                <td>NO</td>    
                                @elseif($consumers[0]->meter_working == 'Y')
                              <td>YES</td>   
                               @else
                               <td></td>        
                                @endif 
                              
                                                        
                            </tr>

                            <tr>
                            <td><b>Connection Status</b></td>
                              @if($consumers[0]->disconnect == 'N') 
                                <td>CONNECTED</td>    
                                @elseif($consumers[0]->disconnect == 'Y')
                              <td>DISCONNECTED</td>   
                              @else
                               <td>NA</td>        
                                @endif     
                              <td><b>Last Reading</b></td>
                              <td>{{ $consumers[0]->last_reading }}</td>
                            
                            </tr>
                            <tr>
                            <td><b>Last Reading Status</b></td>
                              @if($consumers[0]->last_reading_status == 'W') 
                                <td>WORKING</td>
                              @elseif($consumers[0]->last_reading_status == 'D') 
                                <td>DISCONNECTED</td> 
                              @elseif($consumers[0]->last_reading_status == 'T') 
                              <td>NO CONSUMPTION</td>  
                              @elseif($consumers[0]->last_reading_status == 'E') 
                              <td>LESS THAN PREVIOUS READING</td> 
                              @elseif($consumers[0]->last_reading_status == 'L') 
                              <td>GATE/DOOR/CHAMBER LOCKED</td> 
                              @elseif($consumers[0]->last_reading_status == 'F') 
                              <td>METER NOT WORKING</td> 
                              @elseif($consumers[0]->last_reading_status == 'R') 
                              <td>NOT CLEAR</td>           
                              @elseif($consumers[0]->last_reading_status == 'S') 
                              <td>NOT SEEN</td> 
                              @elseif($consumers[0]->last_reading_status == 'C') 
                              <td>NOT ACCESS</td> 
                              @elseif($consumers[0]->last_reading_status == 'M') 
                              <td>SAME READING</td>                              
                               @else
                               <td></td>        
                                @endif 
                              <td><b>Last Reading Date</b></td>
                              <td colspan="3">{{ date('d-M-Y', strtotime($consumers[0]->last_reading_date)) }}</td>                             
                            </tr>

                            <tr>
                              <td><b>Consumer Main Type</b></td>
                              @if($consumer_type)
                                <td>{{ $consumer_type[0]->main_desc }}</td>
                              @else
                                <td></td>
                              @endif  
                              
                              <td><b>Consumer Sub Type</b></td>
                              @if($consumer_type) 
                              <td>{{ $consumer_type[0]->sub_desc }}</td>  
                              @else    
                              <td></td>
                              @endif                           
                               </tr>


                            <tr>
                           <td><b>Office Name</b></td>
                           <td colspan="3">  <a href="" data-toggle="modal" id="meterNo" data-target="#smallModal">
                           {{ $office_name[0]->officename }}
                              </a></td> 
                           </tr> 
                            <tr>    
                              <td><b>Scheme Name</b></td>
                              @if($project_name) 
                                <td colspan="3">{{ $project_name[0]->project_name }}</td>    
                                @else
                              <td colspan="3"></td>        
                                @endif 
                            </tr>                                            
                          </tbody>
                        </table>

                       </br>

                       <span>                       
                       <button type="submit" id="update_btn" class="btn_color btn">
                       Update Information
                                </button>
                       </span><span class="alert"></span>                                        
                        
                          <form method="post" name="consumer_update_form" id="consumer_update_form">
                          @csrf
                          <table class="table table-bordered table-hover" id="consumer_update">
                          
                          <thead>   
                           <tr>
                           <th colspan='4' class="pay_cls"><b>UPDATE DETAILS</b>

                           <button type="button" class="close update_close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                         </button></th>
                           </tr>                         
                          </thead>
                          <tbody>
                            <tr>
                              <td><b>Mobile No.<span class="mandatory_cls">*</span></b></td>
                              <td><input type="number"  pattern="\d{3}[\-]\d{3}[\-]\d{4}" id="mobile_no" value="{{ $user_mob_details[0]->user_mobile }}" maxlength="10" name="mobile_no" required="required">
                                                         
                          </td>
                              <td><b>No. Of Persons</b></td>
                              <td><input type="text" id="no_of_persons" value="{{ $consumers[0]->no_of_persons }}"  maxlength="2" name="no_of_persons"></td>                             
			                      </tr>                          

                            <tr>
                               <td><b>Current Meter Reading </b></td>
                              <td><input type="text" id="current_meter_reading" value="{{ $consumers[0]->current_meter_reading }}" name="current_meter_reading"></td>                             
                              <td><b>Remarks</b></td>
                              <td><textarea id="remarks" class="remarks_cls" name="remarks">{{ $consumers[0]->remarks }}</textarea>
                              </td>                             
			                      
                            </tr>  
                            <tr>
                            <td><b>GIS Longitude</b></td>
                              <td><input type="text" name="gis_long" id="gis_long" value="{{ $consumers[0]->gis_long }}"></td>
                              <td><b>GIS Latitude</b></td>
                              <td><input type="text" name="gis_lati" id="gis_lati" value="{{ $consumers[0]->gis_latid }}"></td>
                             
                            </tr>
                            <tr>
                            <td colspan="4" class="text_align">
                            <button type="submit" id="update_info" class="btn_color btn">
                                  Submit
                                </button>
                            <!-- <input type="submit" id="update_info" class="btn_color" value="Submit"></td> -->
                            </tr>
                          </table>
                          <input type="hidden" id="consumer_id" name="consumer_id" value="<?php echo $consumers[0]->consumer_id ?>">
                          </form>

</br>

                       <table class="table table-bordered table-hover">
                          <thead>   
                           <tr>
                           <th colspan='3' class="pay_cls">METER RELATED DETAILS</th>
                           </tr>                         
                          </thead>
                          <tbody>
                            <tr>
                              <td class="text_align"><a href="" data-toggle="modal" id="pic_details" data-target="#picDetailsModal">
                          Consumption Charge Details</a></td>

                          <td class="text_align"><a href="" data-toggle="modal" id="consumption_details" data-target="#consumptionModal">
                          Consumption Line Graph</a></td>

                         
                              </tr>
                           </tbody>
                         </table>     
                       </br>
                        <table id="example1"  class="table table-bordered table-striped">                       
                          <thead>
                              <tr class="bill_bck_cls">                                
                                  <th><b>Bill Number</b></th>    
                                  <th><b>Paid Date</b></th>
                                  <th><b>Paid Amount(Rs)</b></th>
                                  <th><b>Receipt Number</b></th>
                              </tr>
                          </thead>                        
                          <tbody>
                              @foreach($bill_details as $bill)
                            <tr>       
                                <td> {{ $bill->bill_id }}</td> 
                                <td> {{ date('d-M-Y', strtotime($bill->paid_date)) }}</td>
                                <td> {{ $bill->total_colletd }}</td>
                                <td> {{ $bill->receipt_no }}</td> 
                            </tr>  
                              @endforeach
                          </tbody>
                          </tfoot>
                        </table>
                      </div>
                      <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                  </div>
                </div>
    </div><!-- /.container-fluid -->
  </div>
  <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<div class="modal fade" id="smallModal" tabindex="-1" role="dialog" aria-labelledby="smallModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header"><b>OFFICE DETAILS</b>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    
                </div>
                <div class="modal-body" id="smallBody">
                    <div>
                    <table class="table table-bordered table-striped table-hover" id="meter_table" style='border-collapse: collapse;'>
          <thead>
            <tr>
              <td><b>Circle Office Name</b></td>          
              @if($parentcircle_name) 
              <td>{{ $parentcircle_name[0]->officename }}</td>    
              @else
              <td></td>        
              @endif 
            </tr>
            <tr>
              <td><b>Division Office Name</b></td>
              @if($parentdivision_name) 
              <td>{{ $parentdivision_name[0]->officename }}</td>    
              @else
              <td></td>        
              @endif 
            </tr>
            <tr>
              <td><b>SubDivision Office Name</b></td>
              @if($parentsubdiv_name) 
              <td>{{ $parentsubdiv_name[0]->officename }}</td>    
              @else
              <td></td>        
              @endif          
            </tr>
            
          </thead>
        <tbody></tbody>
     </table>
                        <!-- the result to be displayed apply here -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="picDetailsModal" tabindex="-1" role="dialog" aria-labelledby="picDetailsModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header"><b>CONSUMPTION CHARGE DETAILS</b>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    
                </div>
                <div class="modal-body pic_modal" id="smallBodyPIC">
                    <div>
                    <table class="table table-bordered table-striped table-hover" id="pic_table" style='border-collapse: collapse;'>
          <thead>
          <thead>
                              <tr class="bill_bck_cls">                                
                                  <th><b>Sl No</b></th>    
                                  <th><b>Monthly Consumption(Kilo Liter)</b></th>
                                  <th><b>Monthly Charge(Rs)</b></th>
                                  <th><b>Consumption From</b></th>
                              </tr>
                          </thead>                        
                          <tbody>
                          @if($pic_details)
                              @foreach($pic_details as $index => $pic)
                            <tr>       
                                <td> {{ $index+1 }}</td>
                                <td> {{ $pic->pic_kl }}</td> 
                                <td> {{ $pic->pic_amt }}</td>
                                <td> {{ date('d-M-Y', strtotime($pic->pic_from)) }}</td>
                               
                            </tr>  
                              @endforeach
                            @endif  
                          </tbody>
     </table>
                        <!-- the result to be displayed apply here -->
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="consumptionModal" tabindex="-1" role="dialog" aria-labelledby="consumptionModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header"><b>CONSUMPTION LINE GRAPH</b>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    
                </div>
                <div class="modal-body pic_modal" id="smallBodyPChart">
                   
                    <div id="chartContainer" style="height: 300px;max-width: 100% !important;"></div>
                        <!-- the result to be displayed apply here -->
                    </div>
                </div>
            </div>
        </div>
    </div>



<!-- DataTables  & Plugins -->
   
<script src="{{asset('dash/plugins/canvas/js/jquery-1.11.1.min.js')}}"></script> 
<script src="{{asset('dash/plugins/canvas/js/jquery.canvasjs.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-responsive/js/dataTables.responsive.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-responsive/js/responsive.bootstrap4.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/dataTables.buttons.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/buttons.bootstrap4.min.js')}}"></script>
<script src="{{asset('dash/plugins/jszip/jszip.min.js')}}"></script>
<script src="{{asset('dash/plugins/pdfmake/pdfmake.min.js')}}"></script>
<script src="{{asset('dash/plugins/pdfmake/vfs_fonts.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/buttons.html5.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/buttons.print.min.js')}}"></script>
<script src="{{asset('dash/plugins/datatables-buttons/js/buttons.colVis.min.js')}}"></script>
<script src="{{asset('dash/plugins/ajax/jquery.validate.min.js')}}"></script>


<!-- Page specific script -->
<script>

    $(document).ready(function() {
     
      $(".canvasjs-chart-canvas").hide();
      $("#consumer_update").hide();
      $(".alert").hide();

      $("#example1").DataTable({
        "responsive": true, "lengthChange": false, "autoWidth": false,
        "buttons": ["pdf", "print"]
      }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');     
      
      $('#example1_wrapper').prepend($('<div><h6 class="pay_cls"><b>PAYMENT DETAILS</b></h6></div>'));
      $('#example2').DataTable({
        "paging": true,
        "lengthChange": false,
        "searching": false,
        "ordering": true,
        "info": true,
        "autoWidth": false,
        "responsive": true,
      });

    $(document).on('click', '#update_btn', function(event) {
      $("#consumer_update").show();
      $("#update_btn").hide();
      $(".alert").hide();
    }); 

      $(document).on('click', '.update_close', function(event) {
        $("#consumer_update").hide();
        $("#update_btn").show();
        $(".alert").hide();
      }); 

      $("#mobile_no").keyup(function() {
        $("#mobile_no").val(this.value.match(/[0-9]*/));
      });

      $("#no_of_persons").keyup(function() {
        $("#no_of_persons").val(this.value.match(/[0-9]*/));
      });


        // $('#update_info').click(function(e){
        //        e.preventDefault();
        //        $.ajaxSetup({
        //           headers: {
        //               'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
        //           }
        //       });
        //        $.ajax({
        //           url: "Consumerupdate",
        //           method: 'post',
        //           data: {
        //             consumer_id: $('#consumer_id').val(),
        //             mobile_no: $('#mobile_no').val(),
        //             no_of_persons: $('#no_of_persons').val(),
        //             gis_long: $('#gis_long').val(),    
        //             gis_lati: $('#gis_lati').val()             
        //           },
        //           success: function(result){    
                   
        //             $(".alert").show();
        //              $('.alert').html(result.success);
        //              $("#consumer_update").hide();
        //              $("#update_btn").show();
        //              $("#con_mobile").html($('#mobile_no').val());
        //           }
        //           });
        //        });
           

      
      }); // ready function closed

      if ($("#consumer_update_form").length > 0) {
    $("#consumer_update_form").validate({
      
    rules: {
      mobile_no: {
        required: true,
        maxlength: 10,
        minlength: 10
      }     
    },
    messages: {
      mobile_no: {
         required: "Please Enter Mobile No.",
         maxlength: "Maximum length should be 10",
         minlength: "Minimum length should be 10"
      }
    },
    submitHandler: function(form) {
     $.ajaxSetup({
          headers: {
              'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
          }
      });
      $('#send_form').html('Sending..');
       $.ajax({
                  url: "Consumerupdate",
                  method: 'post',
                  data: {
                    consumer_id: $('#consumer_id').val(),
                    mobile_no: $('#mobile_no').val(),
                    no_of_persons: $('#no_of_persons').val(),
                    current_meter_reading: $('#current_meter_reading').val(),
                    remarks: $('#remarks').val(),
                    gis_long: $('#gis_long').val(),    
                    gis_lati: $('#gis_lati').val()             
                  },
                  success: function(result){  
                    $(".alert").show();
                     $('.alert').html(result.success);
                     $("#consumer_update").hide();
                     $("#update_btn").show();
                     $("#con_mobile").html($('#mobile_no').val());
                  }
           });
    }
  })
}



      
      window.onload = function () {

var options = {
	animationEnabled: true,	
	axisY: {
		title: "Kilo Liter",	
	},
	axisX: {
		title: "Month"
	},
	data: [{
		type: "spline",
		yValueFormatString: "#,##0.0#",
    
		dataPoints: [
			<?php
      if($pic_graph_details)
      {
      foreach($pic_graph_details as $pic_graph) 

      { 
        ?>
			 { label: <?php echo "'".date('d-M-Y', strtotime($pic_graph->pic_from))."'" ?>, y: <?php echo $pic_graph->pic_kl ?> },
      <?php } 
      }  ?>
			
		]
	}]
};
$("#chartContainer").CanvasJSChart(options);

}
  </script>


@endsection