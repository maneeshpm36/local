<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
class HomeController extends Controller
{
    public function home()
    {


      if(Session::has('pen')){

      return view('dashboard/dash');

      }
      else{

        return redirect('/');
      }
    }
}
