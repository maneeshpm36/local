<?php

namespace App\Http\Controllers\Project;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;

class ProjectsController extends Controller
{
    //


    public function ListAllprojects()
    {
      $projects = DB::select('select  * from main.kwa_project_mast');
      return view('project.all',['pjt'=>$projects]);
    }

}
