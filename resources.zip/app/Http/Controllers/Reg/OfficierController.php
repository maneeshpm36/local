<?php

namespace App\Http\Controllers\Reg;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;

class OfficierController extends Controller
{
    //



    public function sigin()
    {
     
      return view('login.login');
    }



    public function registerpage()
    {
      $offices = DB::select('select  * from main.kwa_officemast');
      return view('registration.newstaff',['offs'=>$offices]);
    }


   public function register(Request $request)
    {



      
      $request->validate([
          'name' => 'required|string|max:255',
          'email' => 'required|string|email|max:255',
          'phone' => 'required|max:10',
          'pennum' => 'required|string|max:255',
          'password' => 'required|string|min:8'
      ]);

      $values = array('user_name' => $request->name,'user_email' => $request->email
      ,'user_mobile' => $request->phone,'user_pen' => $request->pennum,'user_type' =>'S');
      DB::table('user')->insert($values);
      return redirect('/')->with("status", " REGISTERATION COMPLETED SUCCESSFULLY LOGIN .");
    }



    public function login(Request $request)
    {
      $logcount=0;
      $request->validate([
          'Username' => 'required|string|max:255',
          'password' => 'required|string|min:8'
      ]);

      $cid=$request->Username;
      $pwd=$request->password;
      $logcount =DB::table('user')->where('user_pen', $cid)->Where('user_type','S')->Where('user_paswd', $pwd)->count();
      if($logcount > 0){

       
        Session::put('pen', $cid);
        Session::put('loggedin', 2);
        return redirect('home');
      }
      else{

        return redirect('/')->with("status", " INVALID ID OR PASSWORD .");
      }
    
    }


    public function logout()
    {
      if(Session::has('loggedin')){
      
        Session::forget('pen');
        Session::forget('loggedin');
      }
      return redirect('/');
    }


}
