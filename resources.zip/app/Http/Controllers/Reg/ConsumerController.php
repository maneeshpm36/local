<?php

namespace App\Http\Controllers\Reg;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;
use App\Models\Kwa_meter;

class ConsumerController extends Controller
{
    //


    public function sigin()
    {
     
      return view('login.consumerlogin');
    }


    public function registerpage()
    {
      $offices = DB::select('select  * from main.kwa_officemast');
      return view('registration.newcons',['offs'=>$offices]);
    }

   public function register(Request $request)
    {
        $request->validate([
          'name' => 'required|string|max:255',
          'consumerid' => 'required|string',
          'password' => 'required|string|min:6',
        
        ]);


    $values = array('user_name' => $request->name,'user_mobile' => $request->phone,
     'user_con_id' => $request->consumerid,'user_paswd' =>$request->password,'user_type' =>'C');


    if(!empty($request->input('birthday'))) {
      $vard =$request->birthday;
      $old_date = explode('/', $vard); 
      $new_data = $old_date[2].'-'.$old_date[1].'-'.$old_date[0];
      $values['user_dob'] = $new_data;         
    }
    if(!empty($request->input('email'))) {
      $request->validate([
        'email' => 'email|string|max:255'
      ]);
      $values['user_email'] = $request->email;         
    }
    if(!empty($request->input('aadhar'))) {
      $request->validate([
        'aadhar' => 'numeric|size:12|regex:^[A-Z]{5}+[0-9]{4}+[A-Z]{1}$'
      ]);
      $values['user_adhar']= $request->aadhar;         
    }
    if(!empty($request->input('user_gender'))) {
   
      $values['user_gender'] = $request->gender;         
    }

    DB::table('user')->insert($values);   
    return redirect('/consumer')->with("status", " REGISTERATION COMPLETED SUCCESSFULLY LOGIN .") ;
    }


    public function login(Request $request)
    {
   
      $logcount=0;
      $request->validate([
          'Username' => 'required|string|max:255',
          'password' => 'required|string'
      ]);

      $mobile=$request->Username;
      $pwd=$request->password;
      $logcount =DB::table('user')->where('user_mobile', $mobile)->Where('user_type','C')->Where('user_paswd', $pwd)->count();


      if($logcount > 0){

        $cid = $consumer_details =DB::table('user')->where('user_mobile', $mobile)->Where('user_type','C')->value('user_con_id');
        Session::put('cid', $cid);
        Session::put('loggedin', 1);
        return redirect('Uhome');
      }
      else{

        return redirect('/consumer')->with("status", " Invalid Mobile Number or Password .") ;
      }
    
    }

    public function userhome()
    {
    
      if(Session::has('cid')){
         $value = Session::get('cid'); 

        //  $area_code = trim($consumer[0]);
        //  $cons_no = trim($consumer[1]);
        //  $cat_code = trim($consumer[2]);
     
           $consumer_details = DB::select("select * from main.kwa_consumer where consumer_id = '$value' ");
     
           $user_mob_details = DB::select("select user_mobile from public.user where user_con_id = '$value'");
      
           $pjt_id = $consumer_details[0]->scheme_code;     
           $area_code = trim($consumer_details[0]->area_code);  
           $consumer_key_id = $consumer_details[0]->key_id;     
           $main_type = $consumer_details[0]->main_type;     
           $sub_type = $consumer_details[0]->sub_type; 

           $consumer_type  = "";
           
           $consumer_type = DB::select("select main_desc,sub_desc from main.kwa_consumer_types where main_type = '$main_type' and sub_type = '$sub_type'");
           
           $project_name = DB::select("select project_name from main.kwa_projects where project_code = '$pjt_id'");
               
           $location_id = $consumer_details[0]->location_id;
           $office_details = DB::select("select officename,parentcircle,parentdivision,parentsubdiv  from main.kwa_officemast where location_id = '$location_id'");
     
          
           $parentcircle_name = $parentdivision_name = $parentsubdiv_name = "";
           $pic_details = $pic_graph_details = "";

           if($office_details[0]->parentcircle != '')
           {
            $parentcircle_code = $office_details[0]->parentcircle;
            $parentcircle_name = DB::select("select officename from main.kwa_officemast where officecode = '$parentcircle_code'");
           }

           if($office_details[0]->parentdivision != '')
           {
            $parentdivision_code = $office_details[0]->parentdivision;
            $parentdivision_name = DB::select("select officename from main.kwa_officemast where officecode = '$parentdivision_code'");
           }
           
           if($office_details[0]->parentsubdiv != '')
           {
            $parentsubdiv_code = $office_details[0]->parentsubdiv;
            $parentsubdiv_name = DB::select("select officename from main.kwa_officemast where officecode = '$parentsubdiv_code'");
           }

           $consumer_no = trim($consumer_details[0]->consumer_no);
           $bill_details = DB::select("select * from main.kwa_collection where area_code= '$area_code' and consumer_no = '$consumer_no' order by paid_date desc");
        

           if($consumer_key_id)
           {
           $pic_details = DB::select("select * from main.kwa_pic_history where key_id = '$consumer_key_id' order by pic_from desc");
        
           $pic_graph_details = DB::select("select * from main.kwa_pic_history where key_id = '$consumer_key_id' order by pic_from desc limit 5");
        
           }
           return view('registration.uhome',['consumers'=> $consumer_details, 'project_name'=> $project_name,
            'office_name' => $office_details, 'bill_details'=> $bill_details, 'parentcircle_name' =>$parentcircle_name,
            'parentdivision_name' => $parentdivision_name, 'parentsubdiv_name' => $parentsubdiv_name, 
            'pic_details' => $pic_details,'pic_graph_details' => $pic_graph_details, 'user_mob_details' => $user_mob_details,
            'consumer_type' => $consumer_type],['user'=>$value]);

      }
      else {  
      return redirect('/');
      }
    }

    public function logout()
    {
      if(Session::has('loggedin')){
      
        Session::forget('cid');
        Session::forget('loggedin');
      }
      return redirect('/');
    }   
    
    public function ConsumerUpdate(Request $request)
    {
      $request->validate([
          'mobile_no' => 'required|max:10',         
      ]);
     
      $consumer_id = $request->consumer_id;
      $mobile_no = $request->mobile_no;  
      $current_meter_reading = $request->current_meter_reading;
      $remarks = $request->remarks;       
      $no_of_persons = $request->no_of_persons;
      $gis_longitude = $request->gis_long;
      $gis_latitude = $request->gis_lati;

      $user_details = DB::select("update public.user set user_mobile = '$mobile_no' where user_con_id = '$consumer_id'");
      
      $consumer_details = DB::select("update main.kwa_consumer set current_meter_reading= '$current_meter_reading',remarks='$remarks',no_of_persons='$no_of_persons', gis_long = '$gis_longitude', gis_latid = '$gis_latitude' where consumer_id = '$consumer_id'");
      
      return response()->json(['success'=>'Updated successfully!']);
         
    }

    public function GetBillDetails(Request $request)
    {
      $request->validate([
        'from_date' => 'required',   
        'to_date' => 'required'       
    ]);

    $consumer_id = $request->consumer_id;
    $from_date = $request->from_date;
    $to_date = $request->to_date;
    

    $consumer_details = DB::select("select * from main.kwa_consumer where consumer_id = '$consumer_id' ");
    $area_code = trim($consumer_details[0]->area_code);  
    $consumer_no = trim($consumer_details[0]->consumer_no);
    

    $payment_data = DB::select("select * from main.kwa_collection where area_code= '$area_code' and consumer_no = '$consumer_no' and paid_date between '$from_date' and '$to_date' order by paid_date desc");
        
    return json_encode($payment_data);
    
    }
     

    public function UpdateMeterReading(Request $request)
    {              

    //   $request->validate([
    //     'current_meter_reading' => 'required'               
    // ]);

      $image_name = '';
      if ($files = $request->file('file')) 
      {     
        // $request()->validate([
        //   'file'  => 'image|mimes:jpeg,png,jpg|max:10240',
        // ]);

        $image_name = time().'.'.$files->getClientOriginalExtension();
         //store file into public folder
        $request->file->move(base_path('public/meter_image'), $image_name);
      }
   
    $values = array('reading_image'=>$image_name,'current_meter_reading' => $request->current_meter_reading,'consumer_id' => $request->consumer_id,
                    'created_date'=> now());
    DB::table('main.kwa_meter_details')->insert($values);

    $meter_data = DB::select("select * from main.kwa_meter_details where consumer_id='$request->consumer_id' order by created_date desc");
    return json_encode($meter_data);
         
    }
}
