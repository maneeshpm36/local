<?php

namespace App\Http\Controllers\SSO;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;

class ApplicationController extends Controller
{
    //

    public function viewApplicatios()
    {

      $applns = DB::select('select  * from kwa_applications');
      return view('applications.all',['apps'=>$applns]);
    
    }


    public function viewApplica()
    {


    $users = DB::connection('pgsql1')->select("SELECT prjt_id, prjt_title, prjt_code FROM pas_project");



    print_r($users);

    }


    public function viewAppRoles()
    {
      
      return view('applications.new');
    }

    public function projectroleList($proj)
    {
        $emloyee = DB::table("public.kwa_appln_roles")->where("aplnid",$proj)->orderBy('rolename')->pluck("rolename","appln_role_id");
        return json_encode($emloyee);
    }


}
