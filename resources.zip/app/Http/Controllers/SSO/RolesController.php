<?php

namespace App\Http\Controllers\SSO;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;

class RolesController extends Controller
{
    public function viewRoles()
    {

      $applnrl = DB::select('select  * from kwa_appln_rolemast');
      return view('applicationrole.all',['apprls'=>$applnrl]);

     
    }
}
