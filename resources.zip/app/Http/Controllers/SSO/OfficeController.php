<?php

namespace App\Http\Controllers\SSO;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;

class OfficeController extends Controller
{
    //

    public function viewAllOffice()
    {
      $offices = DB::select('select  * from main.kwa_officemast');
      return view('office.all',['offs'=>$offices]);
    }




    public function getStates($id)
    {
        $states = DB::table("main.kwa_officemast")->where("district",$id)->pluck("officename","officecode");
        return json_encode($states);
    }


    public function ShowFull()
    {


      $projectroles =DB::table('public.kwa_userrole')->join('public.users', 'kwa_userrole.pen', '=', 'users.pen')
      ->join('public.kwa_appln_roles', 'kwa_userrole.appln_role_id', '=', 'kwa_appln_roles.appln_role_id')
      ->join('kwa_applications', 'kwa_appln_roles.aplnid', '=', 'kwa_applications.aplnid')
      ->get(['kwa_appln_roles.rolename','users.userfullname','users.pen','kwa_applications.aplnname'])
      ->toArray();



      return view('userroles.useradd',['places'=>$places,'desgins'=>$desgins,'projects'=>$projects,'extroles'=>$projectroles]);
    }



    public function viewAllDivisions()
    {
      return view('userrole/newuser');
    }


    public function viewAllSubdivision()
    {
      return view('userrole/newuser');
    }


    public function viewAllSection()
    {
      return view('userrole/newuser');
    }



    public function viewAllQuality()
    {
      return view('userrole/newuser');
    }

    public function viewAllLabs()
    {
      return view('userrole/newuser');
    }

}
