<?php

namespace App\Http\Controllers\SSO;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;

class UserroleController extends Controller
{
    public function home()
    {
      return view('userrole/userhome');
    }

    public function viewroles()
    {
      return view('userrole/newuser');
    }

    public function viewuserroles()
    {
      return view('userrole/newuser');
    }

    public function CreateNew()
    {
      $places = DB::select('select dist_id,dist_name from main.kwa_district order by dist_id');
      $desgins = DB::select('select designid, designation	from main.kwa_designation');
      $projects = DB::select('select aplnid, aplnname	from public.kwa_applications');
      $projectroles =DB::table('public.kwa_userrole')->join('public.users', 'kwa_userrole.pen', '=', 'users.pen')
      ->join('public.kwa_appln_roles', 'kwa_userrole.appln_role_id', '=', 'kwa_appln_roles.appln_role_id')
      ->join('kwa_applications', 'kwa_appln_roles.aplnid', '=', 'kwa_applications.aplnid')
      ->get(['kwa_appln_roles.rolename','users.userfullname','users.pen','kwa_applications.aplnname'])
      ->toArray();
      return view('userroles.useradd',['places'=>$places,'desgins'=>$desgins,'projects'=>$projects,'extroles'=>$projectroles]);
    }


    

    

    

}
