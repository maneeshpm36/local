<?php

namespace App\Http\Controllers\SSO;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;

class UserController extends Controller
{
    //

    public function viewAllUser()
    {
      return view('userrole/newuser');
    }

    public function viewAluserlSuboffice()
    {
      return view('userrole/newuser');
    }
     
    public function employeeList($offid,$desg)
    {
        $emloyee = DB::table("public.users")->where("activeoffice",$offid)->where("designation",$desg)->pluck("userfullname","pen");
        return json_encode($emloyee);
    }


}
