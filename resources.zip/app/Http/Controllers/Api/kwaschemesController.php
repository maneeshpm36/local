<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

use App\Models\kwaschemes;
use DB;
class kwaschemesController extends Controller
{
    //

    public function getAllkwaSchemes() {
       
        $projects = kwaschemes::select('pjt_no as no','pjt_name as name')->where('pjt_status', 'C')->get()->toJson(JSON_PRETTY_PRINT);
        return response($projects, 200);
    }


    public function getAllkwaOffices() {
      
      $offices = DB::table('main.kwa_officemast')->select('officecode as Code','officename as name')->get()->toJson(JSON_PRETTY_PRINT);
      print_r($offices); 
      // return response($offices , 200);
    }

    public function getkwaDivisions() {
      
      $offices = DB::table('main.kwa_officemast')->select('officecode as Code','officename as name')->get()->toJson(JSON_PRETTY_PRINT);
      print_r($offices); 
      // return response($offices , 200);
    }

    public function getkwaSubdivisions() {
      
      $offices = DB::table('main.kwa_officemast')->select('officecode as Code','officename as name')->get()->toJson(JSON_PRETTY_PRINT);
      print_r($offices); 
      // return response($offices , 200);
    }

    public function getkwaSections() {
      
      $offices = DB::table('main.kwa_officemast')->select('officecode as Code','officename as name')->get()->toJson(JSON_PRETTY_PRINT);
      print_r($offices); 
      // return response($offices , 200);
    }

    public function getkwaQuality() {
      
      $offices = DB::table('main.kwa_officemast')->select('officecode as Code','officename as name')->get()->toJson(JSON_PRETTY_PRINT);
      print_r($offices); 
      // return response($offices , 200);
    }

    public function getkwaQualityLabs() {
      
      $offices = DB::table('main.kwa_officemast')->select('officecode as Code','officename as name')->get()->toJson(JSON_PRETTY_PRINT);
      print_r($offices); 
      // return response($offices , 200);
    }

}
