<?php

namespace App\Http\Controllers\Office;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use Session;

class OfficeController extends Controller
{
    //
    public function viewAllOffice()
    {
      $offices = DB::select('select  * from main.kwa_officemast');
      return view('office.all',['offs'=>$offices]);
    }




    public function getStates($id)
    {
        $states = DB::table("main.kwa_officemast")->where("district",$id)->pluck("officename","officecode");
        return json_encode($states);
    }


    public function ShowFull()
    {


      $projectroles =DB::table('public.kwa_userrole')->join('public.users', 'kwa_userrole.pen', '=', 'users.pen')
      ->join('public.kwa_appln_roles', 'kwa_userrole.appln_role_id', '=', 'kwa_appln_roles.appln_role_id')
      ->join('kwa_applications', 'kwa_appln_roles.aplnid', '=', 'kwa_applications.aplnid')
      ->get(['kwa_appln_roles.rolename','users.userfullname','users.pen','kwa_applications.aplnname'])
      ->toArray();



      return view('userroles.useradd',['places'=>$places,'desgins'=>$desgins,'projects'=>$projects,'extroles'=>$projectroles]);
    }



    public function viewAllDivisions()
    {
      return view('userrole/newuser');
    }


    public function viewAllSubdivision()
    {
      return view('userrole/newuser');
    }


    public function viewAllSection()
    {
      return view('userrole/newuser');
    }



    public function viewAllQuality()
    {
      
      // $projects = DB::select('select  * from main.kwa_project_mast');
      // return view('project.all',['pjt'=>$projects]);
  

      $quality = DB::table('main.kwa_officemast')->join('main.office_type', 'kwa_officemast.officetype', '=', 'office_type.offtyp_code')
                    ->join('main.office_class_master', 'kwa_officemast.officeclass', '=', 'office_class_master.office_class_code')
                    ->orderBy('office_class_master.office_class_id', 'asc')
                    ->orderBy('kwa_officemast.officecode', 'asc')               
                    ->where('kwa_officemast.officetype', '=', 'QUA')
                    ->get(['kwa_officemast.officecode as Office_Code','kwa_officemast.officename as Office_Name',
                      'office_type.offtyp_name as Office_Category','office_class_master.office_class_name as Office_Class']);
                    
    
     
     echo "<pre>";
      print_r($quality);   
    echo "<\pre>";  
      
      exit();
       return view('office.qualityall');
      
      
    }


    public function viewAllQua()
    {
      $quality = DB::table('main.kwa_officemast')->join('main.office_type', 'kwa_officemast.officetype', '=', 'office_type.offtyp_code')
                    ->join('main.office_class_master', 'kwa_officemast.officeclass', '=', 'office_class_master.office_class_code')
                    ->orderBy('office_class_master.office_class_id', 'asc')
                    ->orderBy('kwa_officemast.officecode', 'asc')               
                    ->where('kwa_officemast.officetype', '=', 'QUA')
                    ->get(['kwa_officemast.officecode as Office_Code','kwa_officemast.officename as Office_Name',
                      'office_type.offtyp_name as Office_Category','office_class_master.office_class_name as Office_Class'
                      ,'office_class_master.office_class_code as ClassCode']);
      return view('office.quality',['places'=>$quality]);
    }
}
