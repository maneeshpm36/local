<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::get('kwaschemes', 'Api\kwaschemesController@getAllkwaSchemes');  // for listing schemes


Route::get('kwaoffice', 'Api\kwaschemesController@getAllkwaOffices');

Route::get('kwadivisions', 'Api\kwaschemesController@getkwaDivisions');


Route::get('kwasubdivisions', 'Api\kwaschemesController@getkwaSubdivisions');
Route::get('kwasections', 'Api\kwaschemesController@getkwaSections');
Route::get('kwaqualityoffices', 'Api\kwaschemesController@getkwaQuality');
Route::get('kwaqualitylabs', 'Api\kwaschemesController@getkwaQualityLabs');