<?php

use Illuminate\Support\Facades\Route;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



// Route::get('/', function () {
//     return view('login/login');
// });


Route::get('/', 'Reg\OfficierController@sigin');


Route::get('consumer', 'Reg\ConsumerController@sigin')->name('consumer');



Route::get('home', 'HomeController@home')->name('home');

// Applications 
Route::get('applications', 'SSO\ApplicationController@viewApplicatios')->name('applications');
Route::post('newapplications', 'Auth\RegisterController@store');



Route::get('newcom', 'SSO\ApplicationController@viewApplica');


// Roles
Route::get('approles', 'SSO\RolesController@viewRoles')->name('approles');


//Users
Route::get('Users', 'SSO\RolesController@viewRoles')->name('Users');


//Offices

Route::get('Offices', 'Office\OfficeController@viewAllOffice')->name('Offices');
Route::get('OfficeQualitys', 'Office\OfficeController@viewAllQua')->name('OfficeQualitys');




//Projects

Route::get('Projects', 'Project\ProjectsController@ListAllprojects')->name('Projects');




//ConsumerRegisteration
Route::get('Cregister', 'Reg\ConsumerController@registerpage')->name('Cregister');
Route::post('Cregister', 'Reg\ConsumerController@register');
Route::post('Clogin', 'Reg\ConsumerController@login');
Route::get('Uhome', 'Reg\ConsumerController@userhome')->name('Uhome');
Route::get('Clogout', 'Reg\ConsumerController@logout')->name('Clogout');
Route::post('Consumerupdate', 'Reg\ConsumerController@ConsumerUpdate');


//OfficierRegisteration
Route::get('Sregister', 'Reg\OfficierController@registerpage')->name('Sregister');
Route::post('Sregister', 'Reg\OfficierController@register');
Route::post('Slogin', 'Reg\OfficierController@login');
Route::get('Slogout', 'Reg\OfficierController@logout')->name('Slogout');

Route::get('dropdownlist/employee/{off}/{desg}','UserroleController@employeeList');
Route::get('dropdownlist/userroles/{proj}','UserroleController@projectroleList');
Route::get('dropdownlist/getempstates/{id}','UserroleController@getStates');


Route::get('userrole', 'SSO\UserroleController@home');
Route::get('Listurole', 'SSO\UserroleController@viewroles');

//Route::get('Connection', 'Connection\ConnectionController@ListAllConnections')->name('Connection');
Route::get('Connection', 'Connection\ConnectionController@ListAllConnections')->name('Connection');

Route::get('ConnectionDetails', 'Connection\ConnectionController@MonthlyConnectionDetails');
Route::get('ConsumerDateConnection', 'Connection\ConnectionController@ConsumerDateConnectionDetails');

Route::post('GetBillDetails', 'Reg\ConsumerController@GetBillDetails');
Route::post('UpdateMeterReading', 'Reg\ConsumerController@UpdateMeterReading');







// Route::get('kwaschemes', 'Api\kwaschemesController@getAllkwaSchemes');

// Route::get('kwaoffice', 'Api\kwaschemesController@getAllkwaOffices');







Route::get('dropdownlist/employee/{off}/{desg}','UserroleController@employeeList');
Route::get('dropdownlist/userroles/{proj}','UserroleController@projectroleList');
Route::get('dropdownlist/getempstates/{id}','UserroleController@getStates');














Route::get('userrole', 'SSO\UserroleController@home');
Route::get('Listurole', 'SSO\UserroleController@viewroles');
