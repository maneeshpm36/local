<t!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="google-site-verification" content="-c84g2A6scAcVfFj-a8ESTMcYRSGEV8re4nIC4Tr7bY" />


    <title>Kerala Water Authority </title>
<meta propertry ="og:title" content="Kerala Water Authority| Kollam"/>


     

<meta name="author" content="author" />
 <!-- Bootstrap Core CSS -->
 <link rel="shortcut icon" type="image/x-icon" href="../images/water.JPG">
    <link href="../asset/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Font Awesome CSS -->
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    
    
    <!-- Animate CSS -->
    <link href="../css/animate.css" rel="stylesheet" >
    
    <!-- Owl-Carousel -->
    <link rel="stylesheet" href="../css/owl.carousel.css" >
    <link rel="stylesheet" href="../css/owl.theme.css" >
    <link rel="stylesheet" href="../css/owl.transitions.css" >

    <!-- Custom CSS -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/responsive.css" rel="stylesheet">
    <link rel="stylesheet" href="../font-awesome-4.7.0/css/font-awesome.min.css">
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="../css/color/green.css">
    
    
    
    <!-- Colors CSS -->
    <link rel="stylesheet" type="text/css" href="../css/color/blue.css" title="blue">
    <link rel="stylesheet" type="text/css" href="../css/color/green.css" title="green">
    <link rel="stylesheet" type="text/css" href="../css/color/light-red.css" title="light-red">
    
    <link rel="stylesheet" type="text/css" href="../css/color/light-blue.css" title="light-blue">
    <link rel="stylesheet" type="text/css" href="../css/color/yellow.css" title="yellow">
    <link rel="stylesheet" type="text/css" href="../css/color/light-green.css" title="light-green">

    <!-- Custom Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Kaushan+Script' rel='stylesheet' type='text/css'>
    
    
    <!-- Modernizer js -->
    <script src="../js/modernizr.custom.js"></script>
    
    
    
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body class="index">
<?php
  include_once 'connection.php';
  $aeid=$_GET['aeid'];
  ?>
  <table border="0" >
  <tr>
    <td style="align-items: center;">
        <a href="#page-top"><img src="../images/img1.jpg" style="height: 100px" alt="Water Authority"  style="border-radius:25px !important;"></a>
    </td>
  </tr>
</table>
<?php
//
        $m ="SELECT * FROM st_1916 where  st_Id = '$aeid' ";
        $result=mysqli_query($conn,$m);
        $row=mysqli_fetch_array($result);
        
    ?>
<table> <tr>
    <td width="125px"></td>
    <td width="650px" style="color: black"><h3 style="color: blue"><?php echo $row['Name']."(Register complaints(Revenue) )";  ?></h3></td> 
    <td width="300px"></td>
    <td><h4><a class="page-scroll" style="color:orange" href="logout.php">Logout</a></h4></td>
    <td width="30 px"></td>
    <td style="color: green"><h4><a href="login1916h.php?Name=<?php echo $aeid ?>" alt="Home" style="color: green">Back</a></h4></td></tr>
</table>
 
            <table border="0" style="margin-left: 100px">
                        <form onsubmit="return mySubmit()" class="rd-mailform" data-form-output="form-output-global" data-form-type="contact"  id="consumer" name="cin" action=""  method="post" >
                            <div class="range range-20">
                                <div class="cell-sm-6">
                                    <div class="form-wrap form-wrap-validation">
                                        
                               
                                    <div class="form-wrap form-wrap-validation">
                                    <tr>
                                    
                                    <td>
                                        <label class="form-label-outside" for="form-2-phone" style="color:black"> Consumer Id</label>

                                        <input class="form-input"  autocomplete="off" type="text" name="consident" id="conident"  />
                                    </td>  
                            
                                    <td>  
                                      <label class="form-label-outside" for="form-2-phone" style="color:black"> Mobile No: </label>
                                      <input class="form-input" autocomplete="off" type="text" name="consident1" id="conident1" />
                                    </td>
                            </tr>
                            <tr><td>
                                        <br/>                            </td></tr>  
                            <tr><td>                               
                                    </div>
                                </div>
                              

                                
                                
                                <div class="cell-xs-6 offset-custom-1">
                                    <div class="form-button">
                                        <button class="button button-secondary" name="studentsubmit" id="btn-submit" type="submit">Submit</button>
                                    </div>
                                </div>
                              </td><td>
                                <div class="cell-xs-6 offset-custom-1">
                                    <div class="form-button">
                                        <button class="button button-secondary cleandatas" name="studentsubmit" type="reset">Clear</button>
                                    </div>
                                </div>
                            </div>
                            </td></tr> 
                        </form>
                      </table>
                    </div>
                </div>
            </div>
        </section>



      <div class="container con_info">
        <h2>Consumer Information</h2>
        <div class="panel panel-default">



        <table class="table  table-striped">

        <tr><td> Consumer Name   </td>
        <td><span  style="color:blue;" id="con_name" class="abacont"></span>   </td>
        
        </tr>
        <tr><td>Consumer Address    </td>
        <td> <span style="color:blue;" id="con_addr" class="abacont"></span>  </td>
        
        </tr>
        <tr><td>Balance Amount    </td>
        <td> <span style="color:blue;" id="con_amt" class="abacont">  </td>
        
        </tr>
        <tr><td>Section    </td>
        <td> <span style="color:blue;" id="con_sec" class="abacont"></span>  </td>
        
        </tr>

         </table>



         
        </div>
      </div>




        <footer class="style-1">
            <div class="container">
                <div class="row">
                    <div class="col-md-4 col-xs-12">
                        <span class="copyright">Copyright &copy; <a href="http://kollam.gov.in/water-authority">waterauthority</a> <script type="text/javascript">
         var dt = new Date();
         document.write( dt.getFullYear() ); 
      </script>
</span>
                    </div>
                    <div class="col-md-4 col-xs-12">
                       <!-- <div class="footer-social text-center">
                            <ul>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                                <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                        </div>-->
                    </div>
                    <div class="col-md-4 col-xs-12">
                        <div class="footer-link footer-social">
                           
                        </div>
                    </div>
                </div>
            </div>
        </footer>
     
     <!-- jQuery Version 2.1.1 -->
    <script src="../js/jquery-2.1.1.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="../asset/js/bootstrap.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="../js/jquery.easing.1.3.js"></script>
    <script src="../js/classie.js"></script>
    <script src="../js/count-to.js"></script>
    <script src="../js/jquery.appear.js"></script>
    <script src="../js/cbpAnimatedHeader.js"></script>
    <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.fitvids.js"></script>
  <script src="../js/styleswitcher.js"></script>

    <!-- Contact Form JavaScript -->
    <script src="../js/jqBootstrapValidation.js"></script>
    <script src="../contact_me.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="js/script.js"></script>

   
    <script type="text/javascript">
        $(document).ready(function(){
         
            function mySubmit(e) { 
               e.preventDefault(); 
              return false;
            }
         
  
            $("#consumer").submit(function(e){
             return false;
            });

            


            $(document).on('click', '.cleandatas', function()
          { 

                  document.getElementById("con_name").innerHTML="";
                  document.getElementById("con_addr").innerHTML="";
                  document.getElementById("con_amt").innerHTML="";
                  document.getElementById("con_sec").innerHTML="";

                });


            $(document).on('click', '#btn-submit', function()
          { 

                  document.getElementById("con_name").innerHTML="";
                  document.getElementById("con_addr").innerHTML="";
                  document.getElementById("con_amt").innerHTML="";
                  document.getElementById("con_sec").innerHTML="";


            var lol = document.getElementById('conident').value;
            var lol1 = document.getElementById('conident1').value;
            var  urls;
            

            var regExp = /[a-zA-Z]/g;
           if(lol !='') {
                  if(regExp.test(lol)){

                   alert("only Numbers");
                  } else {
                  
                    urls='http://10.64.0.13/consumer/Consumer_info.php?cons_id='+lol;

                   
                  }
           }  
           else if(lol1!='')
           {
            if(regExp.test(lol)){

              alert("only Numbers");
              } else {

              urls='http://10.64.0.13/consumer/Consumer_info.php?cons_ph='+lol1;
              }
           }
           else
           { alert("only Numbers"); }
           

           
            if(urls!=''){


              
              $.ajax({
                type:'GET',
                url:urls,
                contentType: "application/json",
                dataType: 'json',
                success:function(response){ 
                 
                  var myJSON = JSON.stringify(response);
                  var result = $.parseJSON(myJSON);
   
                  if(result.NAME)
                  {
                    document.getElementById("con_name").innerHTML=result.NAME;
                  document.getElementById("con_addr").innerHTML=result.ADDRESS;
                  document.getElementById("con_amt").innerHTML=result.BALANCE_AMOUNT;
                  document.getElementById("con_sec").innerHTML=result.SECTION;
                  }
                  else
                  {
                    alert('Check The Number / No data availavble ');
                  }
                  
                 

                }
              }); 
            }
            else{ alert("Enter an input "); }

            return false;
          });


        
          
          
        });
      </script>
      
    </body>
    </html>
    
    
