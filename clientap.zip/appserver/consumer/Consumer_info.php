<?php
header('HTTP/1.1 200 OK');  
header("Content-Type:application/json");
header('Access-Control-Allow-Origin: *');  
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');  
header('Access-Control-Allow-Headers: Content-Type');  
include('config.php');

 if (isset($_GET['cons_id']) || isset($_GET['cons_ph'])) 
    {
      
        if(isset($_GET['cons_id']) && ($_GET['cons_id']!=""))
        {
            $cons_id = $_GET['cons_id'];
            $parmeter="CONSUMER.CONS_ID_NO =".$cons_id;
        } 

        
        else if(isset($_GET['cons_ph']) && ($_GET['cons_ph']!=""))
        {
               $cons_ph = $_GET['cons_ph'];
               $parmeter="CONSUMER.PHONE =".$cons_ph;
        } 
        else{


            $response['response_code'] = 200;
            $response['response_desc'] = "Invald Parameters";
            $json_response = json_encode($response);
            echo $json_response;
    
        }
       
        




        $query = "select CONSUMER.CONS_NAME as Name, CONSUMER.ARREARS as Balance_amount,LOCATION_MASTER.LOCATION_NAME as section, CONSUMER.ADDRESS1 || ' ' || CONSUMER.ADDRESS2 || ' ' || CONSUMER.ADDRESS3 || ' ' || CONSUMER.ADDRESS4 AS Address 
        from consumer inner join LOCATION_MASTER on  CONSUMER.LOCATION_ID=LOCATION_MASTER.LOCATION_ID WHERE ".$parmeter;

        $s = oci_parse($c, $query);
        if (!$s) {
            // $m = oci_error($c);
            // trigger_error('Could not parse statement: '. $m['message'], E_USER_ERROR);
            $response['response_code'] = 400;
            $response['response_desc'] = "parse Error";
            $json_response = json_encode($response);
            echo $json_response;

        }
        $r = oci_execute($s);
        if (!$r) {
            // $m = oci_error($s);
            // trigger_error('Could not execute statement: '. $m['message'], E_USER_ERROR);
           
            $response['response_code'] = 400;
            $response['response_desc'] = "Query Error";
            $json_response = json_encode($response);
            echo $json_response;


        }
        
        $row = oci_fetch_array($s, OCI_ASSOC+OCI_RETURN_NULLS);
        $num = oci_num_rows($s);
        if($num!=0) {
            $json_response = json_encode($row);
            echo $json_response; 
        }
        else{

            $response['response_code'] = 200;
            $response['response_desc'] = "No Record Found";
            $json_response = json_encode($response);
            echo $json_response;

        }

    }
    else{


        $response['response_code'] = 200;
        $response['response_desc'] = "Invald Parameters";
        $json_response = json_encode($response);
        echo $json_response;

    }
    oci_close($c);


 
?>