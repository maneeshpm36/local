<?php 

$username = "kwa";                  // Use your username
$password = "kwa";             // and your password
$database = "//10.64.0.55:1521/kwa";   // and the connect string to connect to your database
  
$c = oci_connect($username, $password, $database);
if (!$c) {
    $m = oci_error();
    trigger_error('Could not connect to database: '. $m['message'], E_USER_ERROR);
} 